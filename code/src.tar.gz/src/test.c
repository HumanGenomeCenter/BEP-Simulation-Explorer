#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


void decimal2binary( long d, char *s ){
     int i, I[64];
     char buff[64];
     
     for ( i = 0; i < 63; i++ ){
     	  if ( d%2 == 0 ) s[62-i] = '0';
     	  else            s[62-i] = '1';
     	  d >>= 1;
     }

     //for ( i = 0; i < 63; i++ ) strcpy(s+i,buff+62-i);
     
     /* for ( i = 0; i < 63; i++ ){ */
     /* 	  if ( d%2 == 0 ) I[i] = 0; */
     /* 	  else            I[i] = 1; */
     /* 	  d >>= 2; */
     /* } */

     /* for ( i = 0; i < 7; i++ ){ */
     /* 	  sprintf(s+8*i,"%d%d%d%d%d%d%d%d", */
     /* 		  I[8*i  ],I[8*i+1],I[8*i+2],I[8*i+3], */
     /* 		  I[8*i+4],I[8*i+5],I[8*i+6],I[8*i+7] ); */
     /* } */
     
     /* sprintf(s+56,"%d%d%d%d%d%d%d", */
     /* 	     I[56],I[57],I[58],I[59],I[60],I[61],I[62]); */
     
}

long binary2decimalLong( char *buff )
{
     long LL = 0L;
     int i, length;

     length = strlen(buff);
     
     for ( i = 0; i < length-1; i++){
	  //LL += atol( buff+i );
	  if ( buff[i] == '1' ) LL+=1;
	  LL <<= 1;
     }
     
     if ( buff[length-1] == '1' ) LL+=1;

     return LL;
 }


int main( int argc, char *argv[] )
{
     long d;
     char s[64]="";


     while(1){
	  printf("Input long int:");
	  scanf("%ld",&d);
	  if ( d < 0 ) break;

	  printf("\nDecimal expression: %ld\n", d);

	  decimal2binary( d, s );
	  printf("Converted binary expression : %s\n", s);

	  d = binary2decimalLong( s );
	  printf("Restored decimal expression: %ld\n", d);
     }
     
     printf("End.\n");
     
     return 0;
}
