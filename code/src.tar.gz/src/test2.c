#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "util.h"

#define MAXKEY 10000
static
int searchKey( BEPLONG *genome, int G, int nKey, BEPLONG *key )
{
     int i, j, flag;

     for ( i = 0; i < nKey; i++ ){

	  flag = 0;
	  
	  for ( j = 0; j < G; j++ ){

	       if ( genome[j] == key[G*i +j] ) flag++;
	       else break;
	  }

	  if ( flag == G ) return i;
     }

     return -1; //--- Key is not stored.
}

static
int createKey( BEPLONG *key, int **map, BigSimulator2D *SIM )
{
     int nKey, MaxKey;
     int i, j, k, kk, x, y;
     int minX, maxX, minY, maxY;

     BEPLONG *temp;
     
     MaxKey = MAXKEY; // Default number of key array size;
     nKey   = 1;
     minX   = SIM->minX;
     maxX   = SIM->maxX;
     minY   = SIM->minY;
     maxY   = SIM->maxY;
     
     /* ------------------------ */

     for      ( y = minY; y < maxY; y++ ){
	  for ( x = minX; x < maxX; x++ ){

	       i = coordinate2index( x, SIM );
	       j = coordinate2index( y, SIM );

	       k = searchKey( SIM->genomes[i][j], SIM->G, nKey, key ) ;

	       if ( k < 0 ){ //--- New key
		    if ( nKey == MaxKey ){//--- Reallocate key table
			 MaxKey += MAXKEY;
			 temp = (BEPLONG *)realloc( key, MaxKey*SIM->G*sizeof(BEPLONG) );
			 if ( !temp ){
			      fprintf(stderr,"Fail to allocate temporary memory for creating key map.\n");
			      fprintf(stderr,"BEP is aborted by error.\n");
			      abort();
			 }
			 //free(key);
			 key = temp;
		    }
		    
		    for ( kk = 0; kk < SIM->G; kk++ ) key[SIM->G*nKey +kk] = SIM->genomes[i][j][kk];
		    map[ x - minX ][ y - minY ] = nKey;
		    nKey++;
	       }
	       else{
		    map[ x - minX ][ y - minY ] = k;
	       }
	       
	  }
     }
     //fprintf(stderr,"BEP_dbg, (print:createKey) MaxKey = %d\n",MaxKey);
     
     return nKey;     
}

static
void writeTM( int **map, BigSimulator2D *SIM )
{
     FILE *fp;
     char  name[256];
     int   i, j, x, y;
     
     /* ------------ File open ------------ */
     sprintf(name,"%s.tm",SIM->prefix);
     if ( (fp = fopen(name,"w")) == NULL ){
	  fprintf(stderr,"BEP_err: Fail to open %s file.\n",name);
	  exit(0);
     }

     y = SIM->maxY - SIM->minY +1;
     x = SIM->maxX - SIM->minX +1;

     for      ( i = 0; i < y; i++ ){
	  for ( j = 0; j < x; j++ ){
	       fprintf(fp,"%d\t",map[j][i]);
	  }
	  fprintf(fp,"\n");
     }

     fclose(fp);
}

static
void writeMUT( int nKey, BEPLONG *key, BigSimulator2D *SIM )
{
     FILE *fp;
     char  name[256];
     char  buff[MAXBINARY+1] = "";
     //char  *buff;
     int   i, j, G;

     //buff = (char *)malloc( (MAXBINARY+1)*sizeof(char) );
     //if (!buff){
     //  fprintf(stderr,,"Fail to allocate char buffer memory in writing MUT file.\n");
     //  abort();
     //}
     
     /* ------------ File open ------------ */
     sprintf(name,"%s.mut",SIM->prefix);
     if ( (fp = fopen(name,"w")) == NULL ){
	  fprintf(stderr,"BEP_err: Fail to open %s file.\n",name);
	  exit(0);
     }

     G = SIM->G;
     
     for ( i = 0; i < nKey; i++ ){

	  fprintf(fp,"%d\t",i);

	  for ( j = 0; j < G; j++ ){
	       decimal2binary( key[G*i+j], buff );
	       fprintf(fp,"%s",buff);
	  }
	  fprintf(fp,"\n");
     }

     fclose(fp);
     //free(buff);
}

static
void writePRM( BigSimulator2D *SIM )
{
     FILE *fp;
     char  name[256];
     
     /* ------------ File open ------------ */
     sprintf(name,"%s.prm",SIM->prefix);
     if ( (fp = fopen(name,"w")) == NULL ){
	  fprintf(stderr,"BEP_err: Fail to open %s file.\n",name);
	  exit(0);
     }


     fprintf(fp,"mutationRate                   = %e\n",SIM->mutationRate);
     fprintf(fp,"growthRate                     = %e\n",SIM->growthRate);
     fprintf(fp,"deathRate                      = %e\n",SIM->deathRate);
     fprintf(fp,"deathRateForNonStem            = %e\n",SIM->deathRateForNonStem);
     fprintf(fp,"symmetricReplicationProbablity = %e\n",SIM->symmetricReplicationProbablity);
     fprintf(fp,"fitnessIncrease                = %e\n",SIM->fitnessIncrease);

     fprintf(fp,"maxTime               = %d\n",SIM->maxTime);
     fprintf(fp,"maxPopulationSize     = %d\n",SIM->maxPopulationSize);
     fprintf(fp,"genomeSize            = %d\n",SIM->genomeSize);
     fprintf(fp,"driverSize            = %d\n",SIM->driverSize);
     fprintf(fp,"essensialGeneSize     = %d\n",SIM->essensialGeneSize);
     fprintf(fp,"initialPopulationSize = %d\n",SIM->initialPopulationSize);

     fprintf(fp,"populationSize        = %d\n",SIM->populationSize);
     fprintf(fp,"time                  = %d\n",SIM->time);
     fprintf(fp,"{min,max} X           = %d %d\n",SIM->minX,SIM->maxX);
     fprintf(fp,"{min,max} Y           = %d %d\n",SIM->minY,SIM->maxY);
     fprintf(fp,"limXY                 = %d\n",SIM->limXY);
     fprintf(fp,"G                     = %d\n",SIM->G);

     fclose(fp);
}

int main( int argc, char *argv[] )
{
     BigSimulator2D SIM;
     
     int     **map;
     int       nKey;     
     BEPLONG  *key;
     int       i, x, y, *m;
     int       minX, maxX, minY, maxY;

     for ( iter = 10; iter < 1000; iter *= 10; ){
	  fprintf(stderr, "iter = %d\n",iter);
	  
	  /* ------------ Memory allocation ------------ */
	  minX   = -iter;
	  maxX   =  iter;
	  minY   = -iter;
	  maxY   =  iter;

	  key = mallocLong( MAXKEY*SIM->G );
	  for ( i = 0; i < SIM->G; i++ ) key[i] = 0; // Key for vacant

	  y = maxY - minY +1;
	  x = maxX - minX +1;
	  map = (int **)malloc( x*sizeof(int*) );
	  if ( !map ){
	       fprintf(stderr,"Fail to allocate temporary memory for output.\n");
	       fprintf(stderr,"BEP is aborted by error.\n");
	       abort();
	  }
	  m = (int *)malloc( x*y*sizeof(int) );
	  if ( !m ){
	       fprintf(stderr,"Fail to allocate temporary memory for output.\n");
	       fprintf(stderr,"BEP is aborted by error.\n");
	       abort();
	  }
	  for ( i = 0; i < x*y; i++ ) m[i] = -1;
	  for ( i = 0; i < x; i++ ) map[i] = m + y*i;
	  /* ------------------------ */

	  nKey = createKey( key, map, SIM );
     
	  writeTM( map, SIM );
	  writeMUT( nKey, key, SIM );
	  //writePRM( SIM );
     
	  free(key);
	  free(map[0]);
	  free(map);
     }
     
     fprintf(stderr,"Writing results to files...done.\n");
}
