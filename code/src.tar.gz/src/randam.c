#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "struct.h"
#include "MT.h"

#define MERSENNCE_TWISTER

void initRand()
{
#ifdef MERSENNCE_TWISTER
     init_genrand((unsigned)time(NULL));
#else
     srand((unsigned)time(NULL));
#endif     
}

double doubleRand()
{    
     double d;
#ifdef MERSENNCE_TWISTER
     d = genrand_real1();
#else     
     d = rand()/(double)RAND_MAX;
#endif
#ifdef BEP_DEBUG3
     fprintf(stderr,"BEP_dbg: (rand) rand = %e\n", d);
#endif
     return d;
}

int boolRand()
{
     int i;
#ifdef MERSENNCE_TWISTER
     i = genrand_int32()%2;
#else
     i = rand()%2;
#endif
     return i;
}

int intRand( int size )
{
     int i;
#ifdef MERSENNCE_TWISTER
     i = genrand_int32()%size;
#else
     i = rand()%size;
#endif
     return i;
}
