#!/bin/bash -x
#PJM --rsc-list "rscgrp=small"
#PJM --rsc-list "elapse=00:30:00"
#PJM --rsc-list "node=1"
#PJM --mpi "proc=1"
#PJM --mpi "use-rankdir"
#PJM --stg-transfiles all
##PJM --stgin "rank=0 /home/hp120311/k01244/public/R-2.15.3.tar.gz 0:../"
#PJM --stgin "rank=* ./bep %r:./"
#PJM --stgout "rank=* %r:out.* ./Result/"
#PJM -S
#
. /work/system/Env_base
#
./bep
