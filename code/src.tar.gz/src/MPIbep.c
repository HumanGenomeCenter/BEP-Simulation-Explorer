#include<stdio.h>
#include<stdlib.h>
#include <math.h>
#include<mpi.h>

int main( int argc, char *argv[]){

    int nPE,myrank;
    char buff[256];

    int i, j, h, k, l, n, d;
    double f, f2, s, m; 
  
    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&nPE);
    MPI_Comm_rank(MPI_COMM_WORLD,&myrank);

    
    double N[5] =  {5, 6, 7, 8, 9};
    double F[29] = {0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1, 1.05, 1.1, 1.15, 1.2, 1.25, 1.3, 1.35, 1.4, 1.45, 1.5}; 
    double D[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    double S[3] =  {1, 0.1, 0.01};
    double M[3] =  {0.0001, 0.001, 0.01};

    int nMax = 5;
    int fMax = 29;
    int dMax = 10;
    int sMax = 3;
    int mMax = 3;

      
     /* ******** Parameter setting ******** */
    for ( i = 0; i < nMax; i++ ){
	for ( j = 0; j < fMax; j++ ){
	    for ( h = 0; h < dMax; h++ ){
		for ( k = 0; k  < sMax; k++ ){
		    for ( l = 0; l  < mMax; l++ ){
			if (fMax*dMax*sMax*mMax*i + dMax*sMax*mMax*j + sMax*mMax*h + mMax*k + l == myrank ){
			    n = N[i];
			    f= pow(10, F[j]);
			    f2 = F[j];
			    d= D[h];
			    s= S[k];
                            m= M[l];
                            break;
                        }
                     }
                 }
              }
          }
     }

     char file[256];
     sprintf(file, "S%.2f_m%.4f_d%d_f%.2f_%d",s,m,d,f2,n);
sprintf(buff,"./bep  -P 1000000 -G 50 -f %lf  -d %d  -S %lf  -m %lf -o %s  ",f,d,s,m,file);
    //printf(buff);
    system(buff);

     //if ( myrank == 0 ) fprintf(stdout,"MPI_shell: %s\n",argv[1]);
     //system(argv[1]);

     MPI_Finalize();
     return 0; 
}
