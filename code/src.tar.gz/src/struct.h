#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef BIG_SIMULATOR_2D_H
#define BIG_SIMULATOR_2D_H

#ifndef BEPLONG
#define BEPLONG long
#endif

#ifndef Boolean
#define Boolean int
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifdef DEBUG3
#define BEP_DEBUG3
#define BEP_DEBUG2
#define BEP_DEBUG1
#define BEP_DEBUG
#endif

#ifdef DEBUG2
#define BEP_DEBUG2
#define BEP_DEBUG1
#define BEP_DEBUG
#endif

#ifdef DEBUG1
#define BEP_DEBUG1
#define BEP_DEBUG
#endif

#ifdef DEBUG
#define BEP_DEBUG
#endif


#define MAXBINARY 63  // number of digits of max long is 63 in  the binary system
#define MAXGENOME 100 // number of genome arrays is in 100

/* --- Structure for global parameters and variables --- */
struct BigSimulator2D
{
     /* parameters for simulations */
     double mutationRate;
     double growthRate;
     double deathRate;
     double deathRateForNonStem;
     double symmetricReplicationProbablity;
     double fitnessIncrease;

     int maxTime;
     int maxPopulationSize;
     int genomeSize;
     int driverSize;    //--- driverSize  +  essensialGeneSize  <= maxBinary
     int essensialGeneSize;
     int initialPopulationSize;

     //--- variable
     int  G;
     BEPLONG ***genomes; //[1000][1000][1000];


     int limXY;
     int maxX, minX, maxY, minY;
     int populationSize;
     int time;

     //--- This type must be changed properly later. Added by sito at 2013/8/28
     Boolean ***state; //[1000][1000][3]; // occupied differentiated  replicate

     char prefix[256];
};

typedef struct BigSimulator2D BigSimulator2D;

#endif
