#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "util.h"

#define MAXARRAY 10000
//#define BEP_CREATENEIGHBOR_DEBUG

void printResults( BigSimulator2D *SIM );


/* <<<<<<<< >>>>>>>> */
static
int getEmptyNeighbors( int *tmp, int x, int y, BigSimulator2D *SIM ){

     //int tmp[8][2] = {-1}; // Vacant column coordinate
     int i, j, k;

     k = 0;
     for     ( i = x-1; i <= x+1 ; i++){
	  for( j = y-1; j <= y+1 ; j++){

	       if( isEmpty(i,j,SIM) ){

		    tmp[2*k   ] = i;
		    tmp[2*k +1] = j;
		    k++;
	       }

	  }
     }

     return k;
}
/* <<<<<<<< >>>>>>>> */
static
void copyCell( int srcX, int srcY, int dstX, int dstY, BigSimulator2D *SIM )
{
     BEPLONG genome[MAXGENOME];
     Boolean state[3];

     /* ----------- Copy source cell information ------------- */
     getDeeply( genome, srcX, srcY, SIM );
     getStateDeeply( state, srcX, srcY, SIM );

     set( dstX, dstY, genome, state, SIM );
}


/* <<<<<<<< >>>>>>>> */
void createNeighbor( int x, int y, BigSimulator2D *SIM )
{
     //long     genome[MAXGENOME];
     //Boolean  state[3];
     int      neighbor[16];
     int      size;
     int      v[8];
     double   vv[8];
     
     int      i, tmp;
     int      x2, y2;
     int      d, D;
     double   s, r;

     debugMessage(2,"### ### ### ### (neighbor) Enter createNeighbor.\n");
#ifdef BEP_CREATENEIGHBOR_DEBUG
     fprintf(stderr,"### ### ### ### (neighbor) Enter createNeighbor.\n");
#endif

     //strcpy(SIM->prefix,"Before");
     //printResults(SIM); ///////////////Before
     //fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- {min,max}_X = %d %d\n",SIM->minX,SIM->maxX);
     //fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- {min,max}_Y = %d %d\n",SIM->minY,SIM->maxY);


     setRep( x, y, FALSE, SIM ); // Set the cell state normal

     //getDeeply( genome, x, y, SIM );
     //getStateDeeply( state, x, y, SIM );
     size = getEmptyNeighbors( neighbor, x, y, SIM );

     if( size > 0 ){ // --- There are vacant columns
	  debugMessage(2,"--- --- --- --- (neighbor) Success to find vacant cells!\n");
#ifdef BEP_CREATENEIGHBOR_DEBUG
	  fprintf(stderr,"--- --- --- --- (neighbor) Success to find vacant cells!\n");
#endif
	  tmp = intRand( size );

	  x2 = neighbor[2*tmp   ];
	  y2 = neighbor[2*tmp +1];

	  //set( x2, y2, genome, state, SIM );
	  copyCell( x, y, x2, y2, SIM );

	  if( x2 > SIM->maxX ) SIM->maxX = x2;
	  if( x2 < SIM->minX ) SIM->minX = x2;

	  if( y2 > SIM->maxY ) SIM->maxY = y2;
	  if( y2 < SIM->minY ) SIM->minY = y2;

#ifdef BEP_DEBUG3
	  fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- size = %d\n",size);
	  fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- {min,max}_X = %d %d\n",SIM->minX,SIM->maxX);
	  fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- {min,max}_Y = %d %d\n",SIM->minY,SIM->maxY);
	  //exit(0);
#endif
     }else{ // --- There are no vacant column in the vicinity
	  debugMessage(2,"--- --- --- --- (neighbor) There are no vacant column in the vicinity.\n");
#ifdef BEP_CREATENEIGHBOR_DEBUG
	  fprintf(stderr,"--- --- --- --- (neighbor) There are no vacant column in the vicinity.\n");
#endif
	  //right
	  for ( i = 2; x+i <= SIM->limXY; i++ ){

	       if( isEmpty(x+i,y,SIM) ){

		       v[0] = i-1;
		      vv[0] = 1.0 / (double)(i-1);
		      //fprintf(stderr,"(upper) %d:v,vv[0] = %d %e\n",i,v[0],vv[0]);
		     break;
	       }

	  }

	  //upper right
	  for ( i = 2; x+i <= SIM->limXY && y+i <= SIM->limXY; i++ ){

	       if( isEmpty(x+i,y+i,SIM) ){

		      v[1] = i-1;
		     vv[1] = 1.0 / (double)(i-1);
		    break;
	       }

	  }

	  //upper
	  for ( i = 2; y+i <= SIM->limXY; i++ ){

	       if( isEmpty(x,y+i,SIM) ){

		      v[2] = i-1;
		     vv[2] = 1.0 / (double)(i-1);
		    break;
	       }

	  }

	  //upper left
	  for ( i = 2; x-i >= -(SIM->limXY) && y+i <= SIM->limXY; i++ ){

	       if( isEmpty(x-i,y+i,SIM) ){

		      v[3] = i-1;
		     vv[3] = 1.0 / (double)(i-1);
		    break;
	       }

	  }

	  //left
	  for ( i = 2; x-i >= -(SIM->limXY); i++ ){

	       if( isEmpty(x-i,y,SIM) ){

		      v[4] = i-1;
		     vv[4] = 1.0 / (double)(i-1);
		    break;
	       }

	  }

	  //lower left
	  for ( i = 2; x-i >= -(SIM->limXY) && y-i >= -(SIM->limXY); i++ ){

	       if( isEmpty(x-i,y-i,SIM) ){

		      v[5] = i-1;
		     vv[5] = 1.0/ (double)(i-1);
		    break;
	       }

	  }

	  //lower
	  for ( i = 2; y-i >= -(SIM->limXY); i++ ){

	       if( isEmpty(x,y-i,SIM) ){

		      v[6] = i-1;
		     vv[6] = 1.0 / (double)(i-1);
		    break;
	       }

	  }

	  //lower right
	  for ( i = 2; y-i >= -(SIM->limXY) && x+i <= SIM->limXY; i++ ){

	       if( isEmpty(x+i,y-i,SIM) ){

		      v[7] = i-1;
		     vv[7] = 1.0 / (double)(i-1);
		    break;
	       }

	  }
     
	  //for ( i = 0; i < 8; i++ ) fprintf(stderr,"v,vv[%d] = %d %e\n",i,v[i],vv[i]);
	  
	  /* ------------------------ */
	  debugMessage(2,"--- --- --- --- (neighbor) Enter Second block.\n");     
#ifdef BEP_CREATENEIGHBOR_DEBUG
	  fprintf(stderr,"--- --- --- --- (neighbor) Enter Second block.\n");     
#endif
	  s = 0;

	  for( i = 0; i < 8; i++) s += vv[i];
	  for( i = 0; i < 8; i++) vv[i] /= s;

	  r = doubleRand();
	  s = 0.0;
	  d = 0;
	  D = 0;

	  for( i = 0; i < 8; i++){

	       s += vv[i];

	       if( r < s ){

		    d = v[i];
		    D = i+1;
		    break;
	       }

	  }
	  //fprintf(stderr,"D, d = %d %d\n",D,d);
	  //if ( d >= MAXARRAY ) {
	  //   writeMessage("BEP_err","Array size is overflowed!\n");
	  //     writeMessage("BEP_err","Please check MAXARRAY in neighbor.c\n");
	  //     abort();
	  //}

	  if ( D == 1 ){        //right

	       for ( i = d; i >= 0; i-- ) copyCell( x+i, y, x+i+1, y, SIM );

	       if ( x+d+1 > SIM->maxX ) SIM->maxX = x+d+1;

	  } else if ( D == 2 ){ //upper right

	       for ( i = d; i >= 0; i-- ) copyCell( x+i, y+i, x+i+1, y+i+1, SIM );

	       if ( x+d+1 > SIM->maxX ) SIM->maxX = x+d+1;
	       if ( y+d+1 > SIM->maxY ) SIM->maxY = y+d+1;

	  } else if ( D == 3 ){ //upper

	       for ( i = d; i >= 0; i-- ) copyCell( x, y+i, x, y+i+1, SIM );

	       if ( y+d+1 > SIM->maxY ) SIM->maxY = y+d+1;

	  } else if ( D == 4 ){ //upper left

	       for ( i = d; i >= 0; i-- ) copyCell( x-i, y+i, x-i-1, y+i+1, SIM );

	       if ( x-d-1 < SIM->minX ) SIM->minX = x-d-1;
	       if ( y+d+1 > SIM->maxY ) SIM->maxY = y+d+1;

	  } else if ( D == 5 ){ //left

	       for ( i = d; i >= 0; i-- ) copyCell( x-i, y, x-i-1, y, SIM );

	       if ( x-d-1 < SIM->minX ) SIM->minX = x-d-1;

	  } else if ( D == 6 ){ //lower left

	       for ( i = d; i >= 0; i-- ) copyCell( x-i, y-i, x-i-1, y-i-1, SIM );

	       if ( x-d-1 < SIM->minX ) SIM->minX = x-d-1;
	       if ( y-d-1 < SIM->minY ) SIM->minY = y-d-1;

	  } else if ( D == 7 ){ //lower

	       for ( i = d; i >= 0; i-- ) copyCell( x, y-i, x, y-i-1, SIM );

	       if ( y-d-1 < SIM->minY ) SIM->minY = y-d-1;

	  } else if ( D == 8 ){ //lower right

	       for ( i = d; i >= 0; i-- ) copyCell( x+i, y-i, x+i+1, y-i-1, SIM );

	       if ( x+d+1 > SIM->maxX ) SIM->maxX = x+d+1;
	       if ( y-d-1 < SIM->minY ) SIM->minY = y-d-1;
	  }

     }

     //fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- {min,max}_X = %d %d\n",SIM->minX,SIM->maxX);
     //fprintf(stderr,"BEP_dbg: (neighbor) --- --- --- {min,max}_Y = %d %d\n",SIM->minY,SIM->maxY);
     //fprintf(stderr,"D = %d\n",D);
     //strcpy(SIM->prefix,"After");
     //printResults(SIM); ///////////////After
     //exit(0);
          
     debugMessage(2,"### ### ### ### (neighbor) Leave createNeighbor.\n");     
#ifdef BEP_CREATENEIGHBOR_DEBUG
     fprintf(stderr,"### ### ### ### (neighbor) Leave createNeighbor.\n");     
#endif
}

