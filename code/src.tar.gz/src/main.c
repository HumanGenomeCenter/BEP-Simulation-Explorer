#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <getopt.h>
#include <time.h>

#include "util.h"

/****************************************************
 *             Prototype declarations               *
****************************************************/
void growPopulation( BigSimulator2D *SIM );
void printResults( BigSimulator2D *SIM );


/* ******** ******** */
static
void simulate( BigSimulator2D *SIM )
{
     int T, diff;
     time_t  sec_start, sec_end;
     time(&sec_start);
     
     writeMessage("BEP_msg","Start main process.\n");
     
     /* <<<<<<<<  Time marching >>>>>>>> */
     for(T = 1; T <= SIM->maxTime; T++){

	  growPopulation(SIM);

	  if( T%10 == 0 ){
	       fprintf(stderr,"BEP_msg: time = %d \t populationSize = %d\n", T, SIM->populationSize);
	       //printResults( SIM ); /////////////////// For debug
	  }

	  if( abs(SIM->maxX) ==  SIM->limXY || abs(SIM->minX) ==  SIM->limXY ||
	      abs(SIM->maxY) ==  SIM->limXY || abs(SIM->minY) ==  SIM->limXY ){

	       writeMessage("BEP_err","reached space limit!\n");
	       break;

	  }

	  if( SIM->populationSize == 0 || SIM->populationSize >= SIM->maxPopulationSize ) break;

     }

     SIM->time = T;
     time(&sec_end);

     diff = sec_end - sec_start;
     writeMessage("BEP_msg","End main process.\n");
     fprintf(stderr,"BEP_msg: time = %d \t populationSize = %d\n", T, SIM->populationSize);
     fprintf(stdout,"BEP_msg: minX, maxX, minY, maxY, limXY, count = %d %d %d %d %d %d\n",
	     SIM->minX, SIM->maxX, SIM->minY, SIM->maxY, SIM->limXY, count(SIM) );
     fprintf(stdout,"BEP_msg: cpu time = %d\n", diff); 
}


/* ******** ******** */
static
void setMaxMinXY(int x, int y, BigSimulator2D *SIM )
{
#ifdef BEP_DEBUG3
     fprintf(stderr,"BEP_dbg: --- --- --- (main:setMaxMin) (Before) minX, maxX = %d, %d\n",SIM->minX,SIM->maxX);
     fprintf(stderr,"BEP_dbg: --- --- --- (main:setMaxMin) (Before) minY, maxY = %d, %d\n",SIM->minY,SIM->maxY);
#endif

     if( x > SIM->maxX ) SIM->maxX = x;
     if( y > SIM->maxY ) SIM->maxY = y;
     if( x < SIM->minX ) SIM->minX = x;
     if( y < SIM->minY ) SIM->minY = y;

#ifdef BEP_DEBUG3
     fprintf(stderr,"BEP_dbg: --- --- --- (main:setMaxMin) (After) minX, maxX = %d, %d\n",SIM->minX,SIM->maxX);
     fprintf(stderr,"BEP_dbg: --- --- --- (main:setMaxMin) (After) minY, maxY = %d, %d\n",SIM->minY,SIM->maxY);
#endif
}

static
void fillCore( BigSimulator2D *SIM )
{
     int r, x, y;

     debugMessage(2,"--- --- (main:fillCore) Check1\n");

     setNormalCell(0,0,SIM);

     debugMessage(2,"--- --- (main:fillCore) Check2\n");

     SIM->populationSize++;

     debugMessage(2,"--- --- (main:fillCore) Check3\n");

#ifdef BEP_DEBUG3
     {
	  Boolean *state;
	  state = getState(0,0,SIM);
	  fprintf(stderr,"--- --- --- (main:fillCore) Cell[0,0] = %d %d %d\n", state[0],state[1],state[2]);
	  //exit(0);
     }
#endif
     
     if ( SIM->populationSize == SIM->initialPopulationSize) return;

     debugMessage(2,"--- --- (main:fillCore) Check4\n");

     for      ( r = 1; r <SIM->limXY; r++ ){
	  for ( y = r; y > -r; y-- ){

	       setNormalCell(r,y,SIM);
	       setMaxMinXY(r, y,SIM);

	       SIM->populationSize++;

	       if( SIM->populationSize == SIM->initialPopulationSize) return;

	  }

	  for ( x = r; x > -r; x-- ){

	       setNormalCell(x,-r, SIM);
	       setMaxMinXY(x, -r, SIM);

	       SIM->populationSize++;

	       if( SIM->populationSize == SIM->initialPopulationSize ) return;

	  }

	  for ( y = -r; y < r; y++ ){

	       setNormalCell(-r, y, SIM);
	       setMaxMinXY(-r, y, SIM);

	       SIM->populationSize++;

	       if( SIM->populationSize == SIM->initialPopulationSize ) return;

	  }

	  for ( x = -r; x < r; x++ ){

	       setNormalCell(x,r,SIM);
	       setMaxMinXY(x,r,SIM);

	       SIM->populationSize++;

	       if ( SIM->populationSize == SIM->initialPopulationSize ) return;

	  }

     }

     /* ------------ Error handling ------------ */
     writeMessage("BEP_err","Fail to prepare required number of initial cells.\n");
     exit(0);

}


/* ******** ******** */
static
void allocateMemory( BigSimulator2D *SIM )
{
     BEPLONG ***a, **b, *c;
     Boolean ***x, **y, *z;

     int i, size, G;
     
     size = 2*SIM->limXY + 1;
     G    = SIM->G;

     //genomes  = new long[2*limXY+1][2*limXY+1][G];
     //state= new boolean [2*limXY+1][2*limXY+1][3];

     /* ------------------------ */
     a = (BEPLONG ***)malloc(        size*sizeof(BEPLONG**) );
     b = (BEPLONG  **)malloc(   size*size*sizeof(BEPLONG* ) );
     c = (BEPLONG   *)malloc( G*size*size*sizeof(BEPLONG  ) );

     if ( !a || !b || !c ){
	  writeMessage("BEP_err","Fail to allocate genomes array memory.\n");
	  exit(0);
     }

     for ( i = 0; i < G*size*size; i++ ) c[i] = 0L;
     for ( i = 0; i <   size*size; i++ ) b[i] = c + G*i;
     for ( i = 0; i <        size; i++ ) a[i] = b + size*i;

     SIM->genomes = a;

     /* ------------------------ */
     x = (Boolean ***)malloc(        size*sizeof(Boolean**) );
     y = (Boolean  **)malloc(   size*size*sizeof(Boolean* ) );
     z = (Boolean   *)malloc( 3*size*size*sizeof(Boolean  ) );

     if ( !x || !y || !z ){
	  writeMessage("BEP_err","Fail to allocate genomes array memory.\n");
	  exit(0);
     }

     for ( i = 0; i < 3*size*size; i++ ) z[i] = FALSE;
     for ( i = 0; i <   size*size; i++ ) y[i] = z + 3*i;
     for ( i = 0; i <        size; i++ ) x[i] = y + size*i;

     SIM->state = x;

}

static
void freeMemory( BigSimulator2D *SIM )
{
     /* ------------------------ */
     free( SIM->genomes[0][0] );
     free( SIM->genomes[0] );
     free( SIM->genomes );

     /* ------------------------ */
     free( SIM->state[0][0] );
     free( SIM->state[0] );
     free( SIM->state );
}

static
void printUsage()
{
     printf("Usage:\n");
     printf("  -m, --mut      mutaionRate\n");                      //SIM->mutationRate);
     printf("  -D, --death    deathRate\n");                        //SIM->deathRate);
     printf("  -N, --deathns  deathRate for non stem cell\n");      //SIM->deathRateForNonStem);
     printf("  -P, --maxpop   maxPopulationSize\n");                //SIM->maxPopulationSize);
     printf("  -G, --gen      genomeSize\n");                       //SIM->genomeSize);
     printf("  -g, --grow     growthRate\n");                       //SIM->growthRate);
     printf("  -d, --drv      driverSize\n");                       //SIM->driverSize);
     printf("  -e, --ess      essensialGeneSize\n");                //SIM->essensialGeneSize);
     printf("  -f, --fit      fitnessIncrease\n");                  //SIM->fitnessIncrease);
     printf("  -p, --inipop   initialPopulationSize\n");            //SIM->initialPopulationSize);
     printf("  -T, --maxtime  maxTime\n");                          //SIM->maxTime);
     printf("  -S, --sym      symmetric replication probablity\n"); //SIM->symmetricReplicationProbablity);
     printf("  -o, --outfile  outfile prefix\n");
     
}

static
void myOptions ( int argc, char *argv[], BigSimulator2D *SIM )
{
     int  c, option_index;

     static struct option long_options[] =
	  {
	       {"mut",     required_argument, NULL, 'm'}, //"mutaionRate (" + S.mutationRate  + ")"
	       {"death",   required_argument, NULL, 'D'}, //"deathRate (" + S.deathRate  + ")");
	       {"deathns", required_argument, NULL, 'N'}, //"deathRate for non stem cell (" + S.deathRateForNonStem  + ")");
	       {"maxpop",  required_argument, NULL, 'P'}, //"maxPopulationSize (" + S.maxPopulationSize  + ")");
	       {"gen",     required_argument, NULL, 'G'}, //"genomeSize (" + S.genomeSize  + ")");
	       {"grow",    required_argument, NULL, 'g'}, //"growthRate (" + S.growthRate  + ")");
	       {"drv",     required_argument, NULL, 'd'}, //"driverSize (" + S.driverSize  + ")");
	       {"ess",     required_argument, NULL, 'e'}, //"essensialGeneSize (" + S.essensialGeneSize  + ")");
	       {"fit",     required_argument, NULL, 'f'}, //"fitnessIncrease (" + S.fitnessIncrease  + ")");
	       {"inipop",  required_argument, NULL, 'p'}, //"initialPopulationSize (" + S.initialPopulationSize   + ")");
	       {"maxtime", required_argument, NULL, 'T'}, //"maxTime (" + S.maxTime  + ")");
	       {"sym",     required_argument, NULL, 'S'}, //"symmetric replication probablity ("+  S.symmetricReplicationProbablity + ")");
	       {"outfile", required_argument, NULL, 'o'}, //"outfile prefix");
	       {"help",    no_argument,       NULL, 'h'}, //"outfile prefix");
	       {0, 0, 0, 0} // Terminate elements
	  };
     
     while (1){

	  c = getopt_long(argc, argv, "m:D:N:P:G:g:d:e:f:p:T:S:o:h", long_options, &option_index);
	  if ( c == -1 ) break;
	  
	  switch(c){
	  case 'm': SIM->mutationRate                   = atof(optarg); break;
	  case 'D': SIM->deathRate                      = atof(optarg); break;
	  case 'N': SIM->deathRateForNonStem            = atof(optarg); break;
	  case 'P': SIM->maxPopulationSize              = atoi(optarg); break;
	  case 'G': SIM->genomeSize                     = atoi(optarg); break;
	  case 'g': SIM->growthRate                     = atof(optarg); break;
	  case 'd': SIM->driverSize                     = atoi(optarg); break;
	  case 'e': SIM->essensialGeneSize              = atoi(optarg); break;
	  case 'f': SIM->fitnessIncrease                = atof(optarg); break;
	  case 'p': SIM->initialPopulationSize          = atoi(optarg); break;
	  case 'T': SIM->maxTime                        = atoi(optarg); break;
 	  case 'S': SIM->symmetricReplicationProbablity = atof(optarg); break;
	  case 'o': strcpy(SIM->prefix,optarg); break;
	  case 'h': printUsage(); exit(0);

	  case '?':
	       fprintf(stderr,"BEP_err: Illegal option %s is recognized.\n",argv[optind]);
	       exit(EXIT_FAILURE);
	       
	  case ':':
	       fprintf(stderr,"BEP_err: Option %s requires a value.\n", argv[optind]);
	       exit(EXIT_FAILURE);

	  default:
	       printUsage();
	       exit(0);
	  }
	  
     }

}

static
void initializeGenomes( int argc, char *argv[], BigSimulator2D *SIM )
{
     writeMessage("BEP_msg","--- BEP: branching evolutionary processes ---\n\n");    

     /* <<<<<<<< Set default values >>>>>>>> */
     SIM->mutationRate                   = 0.001;
     SIM->growthRate                     = 0.0001;
     SIM->deathRate                      = 0.0000001;
     SIM->deathRateForNonStem            = 0.01;
     SIM->symmetricReplicationProbablity = 1;
     SIM->fitnessIncrease                = 5.0;

     SIM->maxTime               = 5000000;
     SIM->maxPopulationSize     = 100000;
     SIM->genomeSize            = 300;
     SIM->driverSize            = 10;    //--- driverSize  +  essensialGeneSize  <= maxBinary
     SIM->essensialGeneSize     = 0;
     SIM->initialPopulationSize = 10;
     strcpy(SIM->prefix,"out");

     /* <<<<<<<< Get option values >>>>>>>> */
     myOptions ( argc, argv, SIM );
 
     writeMessage("BEP_msg","Initializing conditions...\n");    
     /* <<<<<<<< Set initial values >>>>>>>> */
     SIM->populationSize = 0;
     SIM->time = 0;
     SIM->minX = 0; SIM->maxX = 0;
     SIM->minY = 0; SIM->maxY = 0;
     SIM->limXY = (int) (2*pow(SIM->maxPopulationSize, 0.5));
     SIM->G = SIM->genomeSize / MAXBINARY + 1;

     /* <<<<<<<< Rand seed setting >>>>>>>> */
     initRand();

     /* <<<<<<<< Error handling >>>>>>>> */
     if(SIM->driverSize + SIM->essensialGeneSize  > MAXBINARY || SIM->driverSize + SIM->essensialGeneSize  > SIM->genomeSize){
	  writeMessage("BEP_err","Argument values are illegal in function initializeGenomes.\n");
	  abort();
     }


     allocateMemory( SIM );

     fillCore(SIM);

     writeMessage("BEP_msg","Initializing conditions...done.\n");
}


int main(int argc, char *argv[])
{
     BigSimulator2D SIM;

     initializeGenomes( argc, argv, &SIM );

     simulate( &SIM );

     printResults( &SIM );

     freeMemory( &SIM );
     
     exit(0);
}

