#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "util.h"


Boolean isMutated( int x, int y, int g, BigSimulator2D *SIM )
{
     BEPLONG *genome;
     char     buff[MAXBINARY+1];
     int      n, m;
     
     n = g / MAXBINARY;   //  g = n*maxBinary + m
     m = g % MAXBINARY;

     genome = get(x,y,SIM);
     decimal2binary( genome[n], buff );

     //return isMutatedBody( get(x,y), g, S->maxBinary );     
     if ( buff[m] == '1' ) return TRUE;
     else                                 return FALSE;
}

/* <<<<<<<< Main subroutine >>>>>>>> */
// 1: Mutated gene
// 0: Normal gene
void mutate( int x, int y, BigSimulator2D *S )
{
     BEPLONG *genome;
     char     newMutatedGenes[MAXBINARY+1]; //--- size = S->genomeSize, 1 or 0, no same value
     
     int i, j;

     writeMessage("BEP_dbg","(mutate) --- --- --- --- Enter mutate.\n");
     
     genome = get( x, y, S );

     for ( j = 0; j < S->G; j++){ // Loop for long int compressed genome packets

#ifdef BEP_DEBUG3
	  {
	       int k = 0;
	       //fprintf(stderr,"BEP_dbg: (mutate) --- --- --- --- before genome[%d] = %ld.\n",j,genome[i]);
	  }
#endif

	  decimal2binary( genome[j], newMutatedGenes ); // Convert long value to binary-expression character

	  for ( i = 0; i < MAXBINARY && j*MAXBINARY + i < S->genomeSize; i++ ){

		//if( !isMutated(genome,j*maxBinary + i) & (R.nextDouble() < mutationRate)){
		if( doubleRand() < S->mutationRate ){

		     //newMutatedGenes = genomeLong2mutatedGenes(genome[j]);
		     //newMutatedGenes.add(i);
		     newMutatedGenes[i] = '1';
            //newMutatedGenes[MAXBINARY-1 -i] = '1';
#ifdef BEP_DEBUG3
		     k++;
		     //fprintf(stderr,"BEP_dbg: (mutate) --- --- --- --- gene %d is mutated.\n",j*MAXBINARY+i);
		     //fprintf(stderr,"BEP_dbg: (mutate) --- --- --- --- newMutetedGenes[%d] = %c.\n",j*MAXBINARY+i,newMutatedGenes[i]);
#endif
		}

	   }

	  //genome[j] = mutatedGenes2genomeLong(newMutatedGenes); //<<< return value is long
	  genome[j] = binary2decimalLong( newMutatedGenes );
#ifdef BEP_DEBUG3
	  if ( k > 0 && genome[j] == 0L ) fprintf(stderr,"BEP_dbg: (mutate) --- --- --- --- Mutation indeced but fail to reflect it to genome[%d].\n",j);
	  fprintf(stderr,"BEP_dbg: (mutate) --- --- --- --- after genome[%d] = %ld.\n",j,genome[j]);
#endif
      }

     writeMessage("BEP_dbg","(mutate) --- --- --- --- Leave mutate.\n");
 }
