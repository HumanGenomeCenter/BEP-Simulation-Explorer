#ifndef BEP_UTIL_H
#define BEP_UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "struct.h"
#include "randam.h"


void     writeMessage( char *mode, char *str );
void     debugMessage( int lebel, char *str );
int      coordinate2index( int c, BigSimulator2D *SIM );
BEPLONG* get( int x, int y, BigSimulator2D *SIM );
BEPLONG* mallocLong( int size );
void     getDeeply( BEPLONG *genome, int x, int y, BigSimulator2D *SIM );
void     clear( int x, int y, BigSimulator2D *SIM );
Boolean  isStem( int x, int y, BigSimulator2D *SIM );
Boolean  isEmpty(int x, int y, BigSimulator2D *SIM );
int      count( BigSimulator2D *SIM );
void     decimal2binary( BEPLONG d, char *SIM );
BEPLONG  binary2decimalLong( char *b );
void     setRep(int x, int y, Boolean b, BigSimulator2D *SIM );
Boolean  getRep(int x, int y, BigSimulator2D *SIM );
void     setDif(int x, int y, Boolean b, BigSimulator2D *SIM );
void     getStateDeeply(Boolean *state, int x, int y, BigSimulator2D *SIM );
void     setbody( int x, int y, BEPLONG *genome, BigSimulator2D *SIM );
void     setState(int x, int y, Boolean *sate, BigSimulator2D *SIM );
void     set(int x, int y, BEPLONG *genome, Boolean *state, BigSimulator2D *SIM );
Boolean* getState(int x, int y, BigSimulator2D *SIM );
void     setNormalCell( int x, int y, BigSimulator2D *SIM );

#endif
