#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "struct.h"

#ifndef BEP_MUTATE_H
#define BEP_MUTATE_H

Boolean isMutated( int x, int y, int g, BigSimulator2D *S );

void mutate( int x, int y, BigSimulator2D *S );

#endif
