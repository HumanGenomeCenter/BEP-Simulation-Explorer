#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "struct.h"

#ifndef BEP_RANDAM_H
#define BEP_RANDAM_H

void   initRand();
double doubleRand();
int    boolRand();
int    intRand( int size );

#endif
