#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "struct.h"
#include "util.h"
#include "mutate.h"

extern
void createNeighbor( int x, int y, BigSimulator2D *SIM );

/* ******** ******** */
static
double getFitness(int x, int y, BigSimulator2D *SIM )
{
     double  fitness = 1.0;

     int i;

     for( i = 0; i < SIM->driverSize; i++){

	  if( isMutated(x,y,i,SIM) ) fitness *= SIM->fitnessIncrease; // Coefficient increases by the number of mutated genes

     }

     for( i = SIM->driverSize; i < SIM->driverSize + SIM->essensialGeneSize; i++ ){ // Cell dies because of mutation

	  if( isMutated(x,y,i,SIM) ) fitness = -1;

     }
//#ifdef BEP_DEBUG3
//     fprintf(stderr,"BEP_dbg: --- --- --- (getFitness) fitness = %e.\n",fitness);
//#endif
     return fitness;
}

/* ******** ******** */
static
Boolean growCell1( int x, int y, BigSimulator2D *SIM )
{
     double temp1, temp2;
     
     debugMessage(1,"### ### (growCell1) Enter growCell1.\n");
     
     if( isEmpty(x,y,SIM) ) return TRUE; // cell(x,y) is vacant itself

     if( abs(x) ==  SIM->limXY || abs(y) ==  SIM->limXY) return FALSE; // cell(x,y) is on the boundary

     if( ( isStem(x,y,SIM) && doubleRand() < SIM->deathRate) || // Cell dies and remove it
	 (!isStem(x,y,SIM) && doubleRand() < SIM->deathRateForNonStem) ){

	  debugMessage(2,"--- --- (growCell1) Cell removed because of it's death.\n");
	  clear(x,y,SIM);
	  SIM->populationSize--;

	  return TRUE;
     }


     temp1 = doubleRand();
     temp2 = getFitness(x,y,SIM);
#ifdef BEP_DEBUG3
     fprintf(stderr,"BEP_dbg: --- --- --- (growCell1) getFitness = %e\n",temp2);
#endif

     //if( (doubleRand()) < (getFitness(x,y,SIM) * SIM->growthRate) ){ // Mutation induced into a cell
     if( temp1 < temp2 * SIM->growthRate ){ // Mutation induced into a cell

	  mutate(x,y,SIM);
#ifdef BEP_DEBUG3
	  fprintf(stderr,"BEP_dbg: --- --- --- (growCell1) genome[0][0][0] = %ld\n",SIM->genomes[SIM->limXY][SIM->limXY][0]);
#endif
	  if( temp2 < 0 ){ // Mutation cause death of a cell

	       clear(x,y,SIM);
	       SIM->populationSize--;
	       return TRUE;
	  }

	  setRep(x,y,TRUE,SIM); // Set the cell state mutated
	  #ifdef BEP_DEBUG2
	  {
	       Boolean *state;
	       state = getState(x,y,SIM);
	       if ( state[2] == TRUE ) debugMessage(2,"--- --- (growCell1) setRep is correctly cleared.\n");
	       else                    debugMessage(2,"--- --- (growCell1) setRep didn't set value correctly.\n");
	  }
	  #endif
     }else{

	  setRep(x,y,FALSE,SIM); // Set the cell state normal

     }

     debugMessage(1,"### ### (growCell1) Leave growCell1.\n");
     if( SIM->populationSize >= SIM->maxPopulationSize ) return FALSE;
     else                                                return TRUE;
}

/* <<<<<<<< >>>>>>>> */
static
void replicate( int x, int y, BigSimulator2D *SIM )
{
     debugMessage(2,"### ### ### (replicate) Enter replicate.\n");
//#ifdef BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
     if( SIM->symmetricReplicationProbablity < 1 && isStem(x,y,SIM) ){
	  debugMessage(2,"--- --- --- (replicate) Enter stem cell process.\n");

	  //stem
	  if( doubleRand() > SIM->symmetricReplicationProbablity ){

	       //asymmetric replication
	       if( boolRand() ){

		    setDif(x, y, TRUE, SIM);
		    createNeighbor(x, y, SIM);
		    setDif(x, y, FALSE, SIM);

	       }else{

		    createNeighbor(x, y, SIM);
		    setDif(x, y, TRUE, SIM);

	       }

	  }else{
	       //symmetric replication
	       createNeighbor(x, y, SIM);
	  }

	  debugMessage(2,"--- --- --- (replicate) Leave stem cell process.\n");
     }else{
//#endif
	  //differentiated
	  debugMessage(2,"--- --- --- (replicate) Enter differentiated cell process.\n");
	  //fprintf(stderr,"--- --- --- (replicate) Enter differentiated cell process.\n");
	  createNeighbor(x, y, SIM);
	  //fprintf(stderr,"--- --- --- (replicate) Leave differentiated cell process.\n");
	  debugMessage(2,"--- --- --- (replicate) Leave differentiated cell process.\n");
//#ifdef BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
     }
//#endif
     //fprintf(stderr,"### ### ### (replicate) Leave replicate.\n");
     debugMessage(2,"### ### ### (replicate) Leave replicate.\n");
}

/* ******** ******** */
static
Boolean growCell2( int x, int y, BigSimulator2D *SIM )
{
     debugMessage(1,"### ### (growCell2) Enter growCell2.\n");

     if( isEmpty(x,y,SIM) ) return TRUE;  // If the cell is vacant, return to call point
     debugMessage(2,"--- --- (growCell2) Cell exixts.\n");

     if( abs(x) ==  SIM->limXY || abs(y) ==  SIM->limXY ) return FALSE; // Cell reaches the boundary
     debugMessage(2,"--- --- (growCell2) Cell position is appropriate.\n");

     if(getRep(x,y,SIM)){
	  debugMessage(2,"--- --- (growCell2) Cell is not mutated!\n");

	  replicate(x,y,SIM);
	  debugMessage(2,"--- --- (growCell2) Create a replica of the cell.\n");

	  SIM->populationSize++;
	  debugMessage(2,"--- --- (growCell2) # of population is increased.\n");

     }
     //fprintf(stderr,"### ### (growCell2) Leave growCell2.\n");
     debugMessage(1,"### ### (growCell2) Leave growCell2.\n");
     //fprintf(stderr,"### ### (growCell2) Leave growCell2.\n");
     if ( SIM->populationSize >= SIM->maxPopulationSize ) return FALSE;
     else                                                 return TRUE;
}

/* ******** ******** */
void growPopulation( BigSimulator2D *SIM )
{
     int x, y, r;

     debugMessage(0,"### (growPopulation) Enter growPopulation.\n");

     for     ( x = SIM->minX; x <= SIM->maxX ; x++ ){
	  for( y = SIM->minY; y <= SIM->maxY ; y++ ){

	       if( !growCell1(x,y,SIM) ) return;

	  }
     }
     debugMessage(1,"--- (growPopulation) Clear check1.\n");

     if( !growCell2(0,0,SIM) ) return;
     debugMessage(1,"--- (growPopulation) Clear check2.\n");

     for( r = 1; r <= abs(SIM->maxX) || r <= abs(SIM->minX) ||
	         r <= abs(SIM->maxY) || r <= abs(SIM->minY);   r++ ){

	  if ( r == 1 ) debugMessage(1,"--- (growPopulation) Clear check3.\n");

	  if( boolRand() ){

	       for( y =  r; y > -r; y-- ) if( !growCell2( r, y, SIM) ) return;
	       for( x =  r; x > -r; x-- ) if( !growCell2( x,-r, SIM) ) return;
	       for( y = -r; y <  r; y++ ) if( !growCell2(-r, y, SIM) ) return;
	       for( x = -r; x <  r; x++ ) if( !growCell2( x, r, SIM) ) return;

	  }else{

	       for( x =  r; x > -r; x-- ) if( !growCell2( x, r, SIM) ) return;
	       for( y =  r; y > -r; y-- ) if( !growCell2(-r, y, SIM) ) return;
	       for( x = -r; x <  r; x++ ) if( !growCell2( x,-r, SIM) ) return;
	       for( y = -r; y <  r; y++ ) if( !growCell2( r, y, SIM) ) return;

	  }

     }

     debugMessage(0,"### (growPopulation) Leave growPopulation.\n");
}
