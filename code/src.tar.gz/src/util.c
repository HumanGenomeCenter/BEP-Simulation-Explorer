#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "struct.h"

/* <<<<<<<< >>>>>>>> */
void writeMessage( char *mode, char *str )
{
     char  buff[512];

     strcpy( buff, mode );
     strcat( buff, ": " );
     strcat( buff, str  );

     if      ( strcmp(mode,"BEP_msg") == 0 ){
	  fprintf(stdout,buff);
	  return;
     }
     else if ( strcmp(mode,"BEP_err") == 0 ){
	  fprintf(stderr,buff);
	  return;
     }
}

/* <<<<<<<< >>>>>>>> */
void debugMessage( int level, char *str )
{
     char  buff[512];

     strcpy( buff, "BEP_dbg: " );

#ifdef  BEP_DEBUG3
#define DLEVEL 4
     //strcat( buff, "--- --- --- " );
#elif defined BEP_DEBUG2
#define DLEVEL 3
     //strcat( buff, "--- --- " );
#elif defined BEP_DEBUG1
#define DLEVEL 2
     //strcat( buff, "--- " );
#elif defined BEP_DEBUG
#define DLEVEL 1
#else
#define DLEVEL 0
#endif

     strcat( buff, str );

     if ( level < DLEVEL ) fprintf(stderr,buff);

}

/* <<<<<<<< >>>>>>>> */
int coordinate2index( int c, BigSimulator2D *SIM )
{
     if ( abs(c) > SIM->limXY ){
	  writeMessage("BEP_err","Coordinate is over the limit size.\n");
	  fprintf(stderr,"BEP_err: Input coordinate is %d\n", c);
	  writeMessage("BEP_err","BEP is aborted by error.\n");
	  abort();
     }
     
     return SIM->limXY + c;
}

/* <<<<<<<< >>>>>>>> */
BEPLONG* get( int x, int y, BigSimulator2D *SIM )
{
     int i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);
     
     return SIM->genomes[i][j];
}

/* <<<<<<<< >>>>>>>> */
BEPLONG* mallocLong( int size )
{
     BEPLONG *a;

     a = (BEPLONG *)malloc( size*sizeof(BEPLONG) );
     if ( !a ){
	  fprintf(stderr,"BEP_Error: Fail to allocate %d size of long array.\n", size);
	  abort();
     }

     return a;
}

Boolean* mallocBool( int size )
{
     Boolean *a;

     a = (Boolean *)malloc( size*sizeof(Boolean) );
     if ( !a ){
	  fprintf(stderr,"BEP_Error: Fail to allocate %d size of boolean array.\n", size);
	  abort();
     }

     return a;
}

void getDeeply( BEPLONG *genome, int x, int y, BigSimulator2D *SIM )
{
     int i, j, k;
     
     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     for( k = 0; k < SIM->G ; k++) genome[k] = SIM->genomes[i][j][k];
}

/* <<<<<<<< >>>>>>>> */
void clear( int x, int y, BigSimulator2D *SIM )
{
     int i, j, k;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);
     
     //genomes[i][j] = new long[SIM->G];
     for ( k = 0; k < SIM->G; k++ ) SIM->genomes[i][j][k] = 0;

     SIM->state[i][j][0] = FALSE; //occupied
     SIM->state[i][j][1] = FALSE; //differentiated (stem or not)
     SIM->state[i][j][2] = FALSE; //replicate
}

/* <<<<<<<< >>>>>>>> */
Boolean isStem( int x, int y, BigSimulator2D *SIM )
{
     int i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);
     
     return !SIM->state[i][j][1];

}

/* <<<<<<<< >>>>>>>> */
Boolean isEmpty(int x, int y, BigSimulator2D *SIM )
{
     int i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

//#ifdef DEBUG3
//     fprintf(stderr,"BEP_dbg:(isEmpty) state,!state = %d %d\n",SIM->state[i][j][0],!SIM->state[i][j][0]);
//#endif     
     return !SIM->state[i][j][0];
}

/* <<<<<<<< >>>>>>>> */
int count( BigSimulator2D *SIM )
{
     int tmp = 0;
     int x, y;
     
     for     ( x  = SIM->minX; x <= SIM->maxX ; x++){
	  for( y  = SIM->minY; y <= SIM->maxY ; y++){

	       if( !isEmpty(x,y,SIM) ) tmp++;

	  }
     }

     return tmp;
}

/* <<<<<<<< Convert 64bit integer to binary character >>>>>>>> */
void decimal2binary( BEPLONG d, char *buff ){
     int i;

     for ( i = 0; i < MAXBINARY; i++ ){
     	  if ( d%2 == 0 ) buff[ MAXBINARY-1 -i ] = '0';
     	  else            buff[ MAXBINARY-1 -i ] = '1';
     	  d >>= 1;
     }

     buff[MAXBINARY]='\0';
}

/* <<<<<<<< Convert binary character to 64bit integer >>>>>>>> */
BEPLONG binary2decimalLong( char *buff )
{
     BEPLONG LL = 0L;
     int i, length;

     length = strlen(buff);

     for ( i = 0; i < length-1; i++){
	  //LL += atol( buff+i );
	  if ( buff[i] == '1' ) LL+=1;
	  LL <<= 1;
     }
     
     if ( buff[length-1] == '1' ) LL+=1;

     return LL;
 }

/* <<<<<<<< >>>>>>>> */
void setRep(int x, int y, Boolean b, BigSimulator2D *SIM )
{
     int i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);
     
     SIM->state[i][j][2] = b;

}

/* <<<<<<<< >>>>>>>> */
Boolean getRep(int x, int y, BigSimulator2D *SIM )
{
     int i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);
     
     return SIM->state[i][j][2];

}

/* <<<<<<<< >>>>>>>> */
void setDif(int x, int y, Boolean b, BigSimulator2D *SIM )
{
     int i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     SIM->state[i][j][1] = b;
}

/* <<<<<<<< >>>>>>>> */
void getStateDeeply( Boolean *state, int x, int y, BigSimulator2D *SIM )
{
     int i, j, k;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     for( k = 0; k < 3 ; k++){
       state[k] = SIM->state[i][j][k];
     }
}

/* <<<<<<<< >>>>>>>> */
void setbody( int x, int y, BEPLONG *genome, BigSimulator2D *SIM )
{
     int  i, j, k;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     for( k = 0; k < SIM->G ; k++) SIM->genomes[i][j][k] = genome[k];
     //for( k = 0; k < SIM->G ; k++) SIM->genomes[i][j][k] = 0L;
}

void setState(int x, int y, Boolean *state, BigSimulator2D *SIM )
{
     int  i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     SIM->state[i][j][0] = state[0];
     SIM->state[i][j][1] = state[1];
     SIM->state[i][j][2] = state[2];
     //SIM->state[i][j][0] = TRUE;
     //SIM->state[i][j][1] = FALSE;
     //SIM->state[i][j][2] = FALSE;
}
void set(int x, int y, BEPLONG *genome, Boolean *state, BigSimulator2D *SIM )
{
     setbody( x, y, genome, SIM );
     setState( x, y, state, SIM );
}

Boolean* getState(int x, int y, BigSimulator2D *SIM )
{
     int  i, j;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     return SIM->state[i][j];

}

/* <<<<<<<< >>>>>>>> */
void setNormalCell( int x, int y, BigSimulator2D *SIM )
{
     int  i, j, k;

     i = coordinate2index(x,SIM);
     j = coordinate2index(y,SIM);

     /* ----------- Initialize genome ------------- */
     for( k = 0; k < SIM->G ; k++) SIM->genomes[i][j][k] = 0L;

     /* ----------- Initialize cell state ------------- */
     SIM->state[i][j][0] = TRUE;
     SIM->state[i][j][1] = FALSE;
     SIM->state[i][j][2] = FALSE;
}
